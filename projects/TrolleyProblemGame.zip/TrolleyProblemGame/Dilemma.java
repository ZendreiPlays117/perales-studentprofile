package TrolleyProblemGame;

public abstract class Dilemma {
    protected String title;
    protected String description;
    protected String[] options;
    protected int[] moralityImpacts;
    protected int[] chaosImpacts;
    
    // Getters with encapsulation
    public String getTitle() {
        return title;
    }
    
    public String getDescription() {
        return description;
    }
    
    public String[] getOptions() {
        return options.clone();
    }
    
    public int[] getMoralityImpacts() {
        return moralityImpacts.clone();
    }
    
    public int[] getChaosImpacts() {
        return chaosImpacts.clone();
    }
    
    // Abstract method that subclasses must implement
    public abstract String getOutcomeMessage(int choice);
    
    public String getOptionText(int index) {
        if (index >= 0 && index < options.length) {
            return options[index];
        }
        return "Invalid option";
    }
    
    public int getNumberOfOptions() {
        return options.length;
    }
    
    // Helper method for string repetition (Java 10 compatibility)
    protected String repeatString(String str, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < count; i++) {
            sb.append(str);
        }
        return sb.toString();
    }
    
    // Template method for presenting dilemma
    public final void presentDilemma() {
        System.out.println("\n" + repeatString("=", 60));
        System.out.println("SCENARIO: " + title);
        System.out.println(repeatString("=", 60));
        System.out.println("\n" + description + "\n");
        
        for (int i = 0; i < options.length; i++) {
            System.out.println((i + 1) + ". " + options[i]);
        }
    }
}