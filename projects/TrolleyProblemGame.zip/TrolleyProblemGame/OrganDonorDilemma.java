package TrolleyProblemGame;

public class OrganDonorDilemma extends Dilemma {
    
    public OrganDonorDilemma() {
        this.title = "== THE ORGAN DONOR DILEMMA ==";
        this.description = "You're a transplant coordinator. You have 5 patients needing different organs. " +
                           "A healthy person with matching organs walks in. You could harvest their organs to save the 5.\n" +
                           "What do you do?";
        this.options = new String[]{
            "Harvest the organs - save 5 patients",
            "Don't harvest - let the 5 die",
            "Ask the healthy person to volunteer",
            "Offer payment for their organs"
        };
        this.moralityImpacts = new int[]{-5, 5, 1, -3};
        this.chaosImpacts = new int[]{3, -2, 0, 7};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Harvest organs
            "== YOU HARVESTED THE ORGANS. ==\n\n" +
            "The healthy person goes in for a routine checkup. They never wake up. Their heart, \n" +
            "liver, kidneys, lungs - distributed to 5 waiting patients.\n\n" +
            "5 families celebrate. They throw parties. They thank God for the miracle.\n" +
            "1 family grieves. They bury an empty shell. They demand answers.\n\n" +
            "The 5 recipients don't know where their organs came from. They wouldn't accept them \n" +
            "if they knew. You've saved lives, but you've destroyed trust in medicine forever.\n\n" +
            "When the truth comes out - and it always does - you're arrested. The 5 recipients \n" +
            "return their organs, posthumously. Everyone dies anyway. And you go to prison.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Extreme utilitarianism)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Radical action)",
            
            // Choice 2: Don't harvest
            "== YOU DID NOT HARVEST THE ORGANS. ==\n\n" +
            "The healthy person walks out. They live a full, happy life. They never know how \n" +
            "close they came to death.\n\n" +
            "The 5 patients die, one by one. You watch their families weep. Life support is \n" +
            "turned off. Funerals are scheduled.\n\n" +
            "You did the legal thing. The ethical thing. The thing that doesn't make you a murderer.\n" +
            "But 5 people are dead because you wouldn't make a choice.\n\n" +
            "Their families don't care about your ethics. They care that their loved ones are gone. \n" +
            "'You had the power to save them,' they say. 'Why didn't you?'\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Respecting bodily autonomy)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Predictable inaction)",
            
            // Choice 3: Ask to volunteer
            "== YOU ASKED THE HEALTHY PERSON TO VOLUNTEER. ==\n\n" +
            "You explain the situation. '5 people will die. You can save them, but you'll die too.'\n\n" +
            "They look at you like you're insane. 'You want me to die for strangers? No.' \n" +
            "They leave. They never come back.\n\n" +
            "The 5 patients die. Their families ask if you tried everything. You say yes. \n" +
            "But you know you didn't. You could have saved them. You just couldn't convince \n" +
            "someone to die for them.\n\n" +
            "You respected autonomy. You asked for consent. And 5 people died as a result.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Respecting consent, losing lives)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Following procedure)",
            
            // Choice 4: Offer payment
            "== YOU OFFERED PAYMENT FOR THEIR ORGANS. ==\n\n" +
            "'$1 million,' you offer. 'For your family.' The healthy person considers it. \n" +
            "Their family is poor. Their child needs surgery. The money would save their child.\n\n" +
            "They agree. They sign the forms. They die on the operating table.\n\n" +
            "The 5 patients get their organs. They live. Their families are grateful.\n\n" +
            "But you've created a monster. Now organs have a price. Rich people buy poor people's \n" +
            "organs. The black market explodes. People are kidnapped for their kidneys.\n\n" +
            "You saved 5 lives. You created a system that will kill thousands.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Commodifying the human body)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Creating a market)"
        };
        return messages[choice];
    }
}