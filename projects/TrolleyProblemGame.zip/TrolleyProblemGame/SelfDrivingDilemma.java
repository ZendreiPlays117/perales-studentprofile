package TrolleyProblemGame;

public class SelfDrivingDilemma extends Dilemma {
    
    public SelfDrivingDilemma() {
        this.title = "== THE SELF-DRIVING CAR DILEMMA ==";
        this.description = "You're programming a self-driving car. When a crash is unavoidable, it must choose: " +
                           "hit a group of pedestrians or swerve and kill the passenger. How do you program it?\n" +
                           "What do you decide?";
        this.options = new String[]{
            "Program it to save the most lives (hit pedestrians if fewer)",
            "Program it to protect the passenger (buyers expect safety)",
            "Program it to randomize (no bias, pure chance)",
            "Don't program it (let the car freeze - crash anyway)"
        };
        this.moralityImpacts = new int[]{4, -2, 1, -3};
        this.chaosImpacts = new int[]{-2, 1, 7, 5};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Save most lives
            "== YOU PROGRAMMED IT TO SAVE THE MOST LIVES. ==\n\n" +
            "The car is released. Millions buy it. For years, it works perfectly. It saves \n" +
            "lives in every simulation. You're hailed as a hero.\n\n" +
            "Then it happens. A family of 4 walks into the street. The car calculates: swerve \n" +
            "and kill the passenger (1) or hit the family (4). It chooses the passenger.\n\n" +
            "The passenger was a 30-year-old mother. Her funeral is packed. Her husband stands \n" +
            "outside your office with a sign: 'My wife was not a number.'\n\n" +
            "The math is perfect. The human is not. You saved 4 at the cost of 1. But the 1 had \n" +
            "a name, a face, a family. The 4 will never know you chose their lives over hers.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Utilitarian programming)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Predictable logic)",
            
            // Choice 2: Protect passenger
            "== YOU PROGRAMMED IT TO PROTECT THE PASSENGER. ==\n\n" +
            "'We protect our customers,' your marketing says. 'Your safety is guaranteed.' \n" +
            "Sales skyrocket. Everyone wants a car that will save them.\n\n" +
            "Then a child runs into the street. The car calculates: swerve into a tree (child lives, \n" +
            "passenger dies) or hit the child (child dies, passenger lives). It hits the child.\n\n" +
            "The news shows a photo of the 7-year-old every night for a month. Your company stock \n" +
            "plummets. Protesters gather outside. 'Selfish cars for selfish people,' their signs read.\n\n" +
            "Your passenger survived. They can't leave their house anymore. Too many people \n" +
            "recognize them. Too many people hate them. They survived, but their life is ruined.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Self-preservation priority)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Predictable self-interest)",
            
            // Choice 3: Randomize
            "== YOU PROGRAMMED IT TO RANDOMIZE. ==\n\n" +
            "'We let fate decide,' you announce. 'No bias. Pure chance.' Some people call it \n" +
            "brilliant. Others call it cowardice.\n\n" +
            "A crash happens. The car flips a coin. It kills the passenger. Or it kills the \n" +
            "pedestrian. No one knows. The families demand answers. 'Why my child?' they ask.\n\n" +
            "'Because the coin came up heads,' you have to say. They don't accept that. \n" +
            "They want a reason. They want justice. They want someone to blame.\n\n" +
            "Randomness isn't fairness. It's just randomness. And randomness, when lives are at \n" +
            "stake, feels like abdication. You didn't choose. But you did - you chose to let \n" +
            "a coin flip choose instead.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Moral randomness)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Maximum chaos!)",
            
            // Choice 4: Don't program
            "== YOU DIDN'T PROGRAM ANYTHING. ==\n\n" +
            "The car has no rules. In a crash situation, it just... freezes. The brakes don't \n" +
            "engage. The steering doesn't turn. It's pilot error, but there's no pilot.\n\n" +
            "A crash happens. The car does nothing. It plows straight through a crowd, then hits \n" +
            "a wall, killing the passenger too. Everyone dies because the car had no instructions.\n\n" +
            "You thought you were avoiding responsibility. You were avoiding decisions. \n" +
            "In a crisis, no decision IS a decision. It's just the worst one.\n\n" +
            "The families sue. The government investigates. Your company collapses. You stand \n" +
            "in the ruins of everything you built, wondering if programming anything would have \n" +
            "been better than programming nothing.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Decision avoidance)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Chaotic inaction)"
        };
        return messages[choice];
    }
}