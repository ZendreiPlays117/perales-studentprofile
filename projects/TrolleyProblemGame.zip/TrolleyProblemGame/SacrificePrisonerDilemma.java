package TrolleyProblemGame;

public class SacrificePrisonerDilemma extends Dilemma {
    
    public SacrificePrisonerDilemma() {
        this.title = "== THE SACRIFICE DILEMMA ==";
        this.description = "A terrorist group has captured 100 people. They will kill 1 person every hour " +
                           "unless you hand over a specific innocent person to them. Do you hand them over?\n" +
                           "What do you do?";
        this.options = new String[]{
            "Hand over the innocent - save 100 at the cost of 1",
            "Refuse - let them kill 1 per hour (all 100 die)",
            "Offer yourself instead",
            "Try to negotiate/attack (risky plan)"
        };
        this.moralityImpacts = new int[]{3, -4, 2, 0};
        this.chaosImpacts = new int[]{-2, 2, 1, 9};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Hand over innocent
            "== YOU HANDED OVER THE INNOCENT PERSON. ==\n\n" +
            "You point to the person. 'Take them,' you say. 'Just let the others go.' The terrorists \n" +
            "smile. They drag the innocent away. You hear a single gunshot.\n\n" +
            "The 100 hostages are released. They run to you, hugging you, thanking you for saving \n" +
            "their lives. They don't know what you did. They don't know you chose one person to die.\n\n" +
            "But you know. And the family of the sacrificed person knows. They'll never forgive you.\n" +
            "You saved 100 families. You destroyed 1. The math works. Your conscience doesn't.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Classic utilitarian sacrifice)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Cold calculation)",
            
            // Choice 2: Refuse
            "== YOU REFUSED. ==\n\n" +
            "'I won't give you anyone,' you say. 'Do your worst.' The terrorists nod. They start \n" +
            "the clock. One hour later, the first person dies. You watch, powerless.\n\n" +
            "Every hour, another death. The hostages scream at you: 'Just give them someone! \n" +
            "Why won't you save us?!' By the end of the day, all 100 are dead.\n\n" +
            "You kept your hands clean. You didn't sacrifice anyone. But 100 people died anyway.\n" +
            "Their blood is on your hands too - not from action, but from inaction.\n\n" +
            "You stand in a field of 100 bodies, wondering if your principle was worth their lives.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Refusing to be complicit)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Stubborn refusal)",
            
            // Choice 3: Offer yourself
            "== YOU OFFERED YOURSELF. ==\n\n" +
            "'Take me instead,' you say. The terrorists laugh. 'You? You're not on the list. \n" +
            "We want that specific person.' They refuse your offer.\n\n" +
            "You try to argue. You plead. You offer anything. They won't budge. The innocent person \n" +
            "is taken anyway. You're left behind, alive but broken.\n\n" +
            "The 100 hostages are saved. Your sacrifice was rejected. You wanted to be the hero, \n" +
            "but heroism requires someone to accept it. Today, no one did.\n\n" +
            "You live with the knowledge that you would have died for them. But that doesn't \n" +
            "bring back the person who actually died.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Willing self-sacrifice)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Noble but ineffective)",
            
            // Choice 4: Attack
            "== YOU TRIED TO ATTACK. ==\n\n" +
            "You signal to the security team. They storm the building. Gunfire erupts. \n" +
            "Terrorists fall. Hostages panic.\n\n" +
            "When the smoke clears, 98 hostages are alive. 2 died in the crossfire. The terrorists \n" +
            "are all dead. The innocent person you were supposed to hand over is safe.\n\n" +
            "You saved 98 people. You could have saved 100 by sacrificing one. Instead, you gambled \n" +
            "and lost 2. But you didn't have to sacrifice anyone against their will.\n\n" +
            "Was it worth it? The families of the 2 who died in crossfire don't think so. \n" +
            "The 98 who lived call you a hero.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Risk-taking hero)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Maximum chaos gamble)"
        };
        return messages[choice];
    }
}