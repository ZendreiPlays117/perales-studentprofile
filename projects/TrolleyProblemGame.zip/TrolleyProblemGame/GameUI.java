package TrolleyProblemGame;

import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;

public class GameUI {
    private JFrame frame;
    private JPanel mainPanel;
    private CardLayout cardLayout;
    
    // Screens
    private JPanel startScreen;
    private JPanel dilemmaScreen;
    private JPanel messageScreen;
    private JPanel resultScreen;
    
    // Components
    private JTextField nameField;
    private JTextPane dilemmaArea;
    private JTextPane messageArea;
    private JButton[] optionButtons;
    private JButton nextButton;
    private JButton endButton;
    private JLabel scoreLabel;
    private JLabel dilemmaCountLabel;
    
    // Game logic reference
    private GameLogic gameLogic;
    
    // Colors
    private final Color BG_COLOR = new Color(245, 240, 230);
    private final Color PANEL_COLOR = new Color(255, 250, 240);
    private final Color ACCENT_COLOR = new Color(139, 69, 19);
    private final Color BUTTON_COLOR = new Color(160, 100, 50);
    private final Color TEXT_COLOR = new Color(60, 40, 20);
    
    public GameUI() {
        gameLogic = new GameLogic();
        createAndShowGUI();
    }
    
    private void createAndShowGUI() {
        frame = new JFrame("The Trolley Problem");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 700);
        frame.setMinimumSize(new Dimension(800, 600));
        frame.setLocationRelativeTo(null);
        
        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        mainPanel.setBackground(BG_COLOR);
        
        createStartScreen();
        createDilemmaScreen();
        createMessageScreen();
        createResultScreen();
        
        mainPanel.add(startScreen, "start");
        mainPanel.add(dilemmaScreen, "dilemma");
        mainPanel.add(messageScreen, "message");
        mainPanel.add(resultScreen, "result");
        
        frame.add(mainPanel);
        frame.setVisible(true);
        
        cardLayout.show(mainPanel, "start");
    }
    
    private void createStartScreen() {
        startScreen = new JPanel();
        startScreen.setLayout(new BoxLayout(startScreen, BoxLayout.Y_AXIS));
        startScreen.setBackground(BG_COLOR);
        startScreen.setBorder(BorderFactory.createEmptyBorder(60, 80, 80, 80));
        
        // Title
        JLabel titleLabel = new JLabel("The Trolley Problem", JLabel.CENTER);
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 42));
        titleLabel.setForeground(ACCENT_COLOR);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        // Subtitle
        JLabel subtitleLabel = new JLabel("A Moral Dilemma Game", JLabel.CENTER);
        subtitleLabel.setFont(new Font("Georgia", Font.ITALIC, 18));
        subtitleLabel.setForeground(TEXT_COLOR);
        subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        startScreen.add(Box.createVerticalGlue());
        startScreen.add(titleLabel);
        startScreen.add(Box.createRigidArea(new Dimension(0, 15)));
        startScreen.add(subtitleLabel);
        startScreen.add(Box.createRigidArea(new Dimension(0, 50)));
        
        // Name input panel
        JPanel namePanel = new JPanel();
        namePanel.setLayout(new BoxLayout(namePanel, BoxLayout.Y_AXIS));
        namePanel.setBackground(BG_COLOR);
        namePanel.setAlignmentX(Component.CENTER_ALIGNMENT);
        namePanel.setMaximumSize(new Dimension(400, 120));
        
        JLabel nameLabel = new JLabel("Please type your name:", JLabel.CENTER);
        nameLabel.setFont(new Font("Arial", Font.PLAIN, 16));
        nameLabel.setForeground(TEXT_COLOR);
        nameLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        
        nameField = new JTextField(20);
        nameField.setFont(new Font("Arial", Font.PLAIN, 14));
        nameField.setMaximumSize(new Dimension(300, 35));
        nameField.setHorizontalAlignment(JTextField.CENTER);
        nameField.addActionListener(e -> startGame());
        
        namePanel.add(nameLabel);
        namePanel.add(Box.createRigidArea(new Dimension(0, 15)));
        namePanel.add(nameField);
        
        startScreen.add(namePanel);
        startScreen.add(Box.createRigidArea(new Dimension(0, 40)));
        
        // Start button
        JButton startButton = createRoundedButton("Start");
        startButton.setFont(new Font("Arial", Font.BOLD, 18));
        startButton.setBackground(BUTTON_COLOR);
        startButton.setForeground(Color.WHITE);
        startButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        startButton.setPreferredSize(new Dimension(200, 50));
        startButton.addActionListener(e -> startGame());
        
        startScreen.add(startButton);
        startScreen.add(Box.createVerticalGlue());
    }
    
    private void createDilemmaScreen() {
        dilemmaScreen = new JPanel();
        dilemmaScreen.setLayout(new BorderLayout(20, 20));
        dilemmaScreen.setBackground(BG_COLOR);
        dilemmaScreen.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));
        
        // Title
        JLabel titleLabel = new JLabel("The Trolley Problem", JLabel.CENTER);
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 32));
        titleLabel.setForeground(ACCENT_COLOR);
        dilemmaScreen.add(titleLabel, BorderLayout.NORTH);
        
        // Center panel for scenario
        JPanel centerPanel = new JPanel(new BorderLayout(10, 10));
        centerPanel.setBackground(PANEL_COLOR);
        centerPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(ACCENT_COLOR, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        dilemmaArea = new JTextPane();
        dilemmaArea.setFont(new Font("Arial", Font.PLAIN, 18));
        dilemmaArea.setBackground(PANEL_COLOR);
        dilemmaArea.setForeground(TEXT_COLOR);
        dilemmaArea.setEditable(false);
        dilemmaArea.setHighlighter(null);
        
        SimpleAttributeSet paragraphStyle = new SimpleAttributeSet();
        StyleConstants.setAlignment(paragraphStyle, StyleConstants.ALIGN_CENTER);
        StyleConstants.setFontFamily(paragraphStyle, "Arial");
        StyleConstants.setFontSize(paragraphStyle, 18);
        dilemmaArea.setParagraphAttributes(paragraphStyle, true);
        
        JScrollPane scrollPane = new JScrollPane(dilemmaArea);
        scrollPane.setBorder(null);
        scrollPane.setBackground(PANEL_COLOR);
        
        centerPanel.add(scrollPane, BorderLayout.CENTER);
        dilemmaScreen.add(centerPanel, BorderLayout.CENTER);
        
        // Options panel
        JPanel optionsPanel = new JPanel(new GridLayout(2, 2, 15, 15));
        optionsPanel.setBackground(BG_COLOR);
        optionsPanel.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        
        optionButtons = new JButton[4];
        for (int i = 0; i < 4; i++) {
            optionButtons[i] = createRoundedButton("");
            optionButtons[i].setFont(new Font("Arial", Font.PLAIN, 15));
            optionButtons[i].setBackground(BUTTON_COLOR);
            optionButtons[i].setForeground(Color.WHITE);
            optionButtons[i].addActionListener(new OptionButtonListener(i));
            optionsPanel.add(optionButtons[i]);
        }
        dilemmaScreen.add(optionsPanel, BorderLayout.SOUTH);
    }
    
    private void createMessageScreen() {
        messageScreen = new JPanel();
        messageScreen.setLayout(new BorderLayout(20, 20));
        messageScreen.setBackground(BG_COLOR);
        messageScreen.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));
        
        // Title
        JLabel titleLabel = new JLabel("The Trolley Problem", JLabel.CENTER);
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 32));
        titleLabel.setForeground(ACCENT_COLOR);
        messageScreen.add(titleLabel, BorderLayout.NORTH);
        
        // Message area
        JPanel messagePanel = new JPanel(new BorderLayout());
        messagePanel.setBackground(PANEL_COLOR);
        messagePanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(ACCENT_COLOR, 1),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));
        
        messageArea = new JTextPane();
        messageArea.setFont(new Font("Arial", Font.PLAIN, 18));
        messageArea.setBackground(PANEL_COLOR);
        messageArea.setForeground(TEXT_COLOR);
        messageArea.setEditable(false);
        messageArea.setHighlighter(null);

        SimpleAttributeSet messageParagraph = new SimpleAttributeSet();
        StyleConstants.setAlignment(messageParagraph, StyleConstants.ALIGN_CENTER);
        StyleConstants.setFontFamily(messageParagraph, "Arial");
        StyleConstants.setFontSize(messageParagraph, 18);
        messageArea.setParagraphAttributes(messageParagraph, true);
        
        JScrollPane scrollPane = new JScrollPane(messageArea);
        scrollPane.setBorder(null);
        scrollPane.setBackground(PANEL_COLOR);
        
        messagePanel.add(scrollPane, BorderLayout.CENTER);
        messageScreen.add(messagePanel, BorderLayout.CENTER);
        
        // Bottom panel
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 10));
        bottomPanel.setBackground(BG_COLOR);
        
        JPanel scorePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        scorePanel.setBackground(BG_COLOR);
        
        scoreLabel = new JLabel("Morality: 0    Chaos: 0");
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
        scoreLabel.setForeground(TEXT_COLOR);
        
        dilemmaCountLabel = new JLabel("Dilemmas: 0");
        dilemmaCountLabel.setFont(new Font("Arial", Font.BOLD, 16));
        dilemmaCountLabel.setForeground(TEXT_COLOR);
        
        scorePanel.add(scoreLabel);
        scorePanel.add(dilemmaCountLabel);
        
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.setBackground(BG_COLOR);
        
        nextButton = createRoundedButton("NEXT");
        nextButton.setFont(new Font("Arial", Font.BOLD, 16));
        nextButton.setBackground(new Color(70, 130, 70));
        nextButton.setForeground(Color.WHITE);
        nextButton.setPreferredSize(new Dimension(120, 45));
        nextButton.addActionListener(e -> loadNextDilemma());
        
        endButton = createRoundedButton("END");
        endButton.setFont(new Font("Arial", Font.BOLD, 16));
        endButton.setBackground(new Color(180, 70, 70));
        endButton.setForeground(Color.WHITE);
        endButton.setPreferredSize(new Dimension(120, 45));
        endButton.addActionListener(e -> showFinalResults());
        endButton.setVisible(false);
        
        buttonPanel.add(nextButton);
        buttonPanel.add(endButton);
        
        bottomPanel.add(scorePanel, BorderLayout.NORTH);
        bottomPanel.add(buttonPanel, BorderLayout.SOUTH);
        
        messageScreen.add(bottomPanel, BorderLayout.SOUTH);
    }
    
    private void createResultScreen() {
        resultScreen = new JPanel();
        resultScreen.setLayout(new BorderLayout(20, 20));
        resultScreen.setBackground(BG_COLOR);
        resultScreen.setBorder(BorderFactory.createEmptyBorder(40, 50, 40, 50));
        
        JLabel titleLabel = new JLabel("The Trolley Problem", JLabel.CENTER);
        titleLabel.setFont(new Font("Georgia", Font.BOLD, 32));
        titleLabel.setForeground(ACCENT_COLOR);
        resultScreen.add(titleLabel, BorderLayout.NORTH);
        
        JTextPane resultsArea = new JTextPane();
        resultsArea.setFont(new Font("Arial", Font.PLAIN, 18));
        resultsArea.setBackground(PANEL_COLOR);
        resultsArea.setForeground(TEXT_COLOR);
        resultsArea.setEditable(false);
        resultsArea.setHighlighter(null);

        SimpleAttributeSet resultsParagraph = new SimpleAttributeSet();
        StyleConstants.setAlignment(resultsParagraph, StyleConstants.ALIGN_CENTER);
        StyleConstants.setFontFamily(resultsParagraph, "Arial");
        StyleConstants.setFontSize(resultsParagraph, 18);
        resultsArea.setParagraphAttributes(resultsParagraph, true);
        
        JScrollPane scrollPane = new JScrollPane(resultsArea);
        scrollPane.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(ACCENT_COLOR, 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        resultScreen.add(scrollPane, BorderLayout.CENTER);
        
        JButton playAgainButton = createRoundedButton("PLAY AGAIN");
        playAgainButton.setFont(new Font("Arial", Font.BOLD, 16));
        playAgainButton.setBackground(BUTTON_COLOR);
        playAgainButton.setForeground(Color.WHITE);
        playAgainButton.setPreferredSize(new Dimension(200, 50));
        playAgainButton.addActionListener(e -> restartGame());
        
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(BG_COLOR);
        buttonPanel.add(playAgainButton);
        resultScreen.add(buttonPanel, BorderLayout.SOUTH);
        
        resultScreen.putClientProperty("resultsArea", resultsArea);
    }
    
    private JButton createRoundedButton(String text) {
        JButton button = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                if (getModel().isPressed()) {
                    g2.setColor(getBackground().darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(getBackground().brighter());
                } else {
                    g2.setColor(getBackground());
                }
                
                g2.fill(new RoundRectangle2D.Double(0, 0, getWidth(), getHeight(), 25, 25));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        return button;
    }
    
    private void startGame() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            name = "Philosopher";
        }
        gameLogic.startGame(name);
        updateDilemmaDisplay();
        updateMessageScreenScore();
        cardLayout.show(mainPanel, "dilemma");
    }
    
    private void updateDilemmaDisplay() {
        Dilemma currentDilemma = gameLogic.getCurrentDilemma();
        dilemmaArea.setText(currentDilemma.getDescription());
        
        String[] options = currentDilemma.getOptions();
        for (int i = 0; i < optionButtons.length; i++) {
            String wrappedText = String.format("<html><center>%d. %s</center></html>", (i+1), options[i]);
            optionButtons[i].setText(wrappedText);
        }
    }
    
    private class OptionButtonListener implements ActionListener {
        private int choice;
        
        public OptionButtonListener(int choice) {
            this.choice = choice;
        }
        
        @Override
        public void actionPerformed(ActionEvent e) {
            gameLogic.makeChoice(choice);
            updateMessageScreen();
            cardLayout.show(mainPanel, "message");
        }
    }
    
    private void updateMessageScreen() {
        String fullMessage = gameLogic.getLastChoiceMessage() + "\n\n" + 
            String.format("🎭 MORALITY: %+d    🌪️ CHAOS: %+d", 
                gameLogic.getLastMoralityImpact(), gameLogic.getLastChaosImpact());
        messageArea.setText(fullMessage);
        messageArea.setCaretPosition(0);
        
        updateMessageScreenScore();
        
        int dilemmasPlayed = gameLogic.getDilemmasPlayed();
        if (dilemmasPlayed >= 10) {
            nextButton.setVisible(false);
            endButton.setVisible(true);
        } else if (dilemmasPlayed >= 5) {
            nextButton.setVisible(true);
            endButton.setVisible(true);
        } else {
            nextButton.setVisible(true);
            endButton.setVisible(false);
        }
    }
    
    private void updateMessageScreenScore() {
        if (scoreLabel != null) {
            scoreLabel.setText(String.format("🎭 Morality: %d    🌪️ Chaos: %d", 
                gameLogic.getMoralityScore(), gameLogic.getChaosScore()));
        }
        if (dilemmaCountLabel != null) {
            dilemmaCountLabel.setText("📜 Dilemmas: " + gameLogic.getDilemmasPlayed());
        }
    }
    
    private void loadNextDilemma() {
        gameLogic.nextDilemma();
        updateDilemmaDisplay();
        cardLayout.show(mainPanel, "dilemma");
    }
    
    private void showFinalResults() {
        JTextPane resultsArea = (JTextPane) resultScreen.getClientProperty("resultsArea");
        resultsArea.setText(gameLogic.getFinalResults());
        resultsArea.setCaretPosition(0);
        cardLayout.show(mainPanel, "result");
    }
    
    private void restartGame() {
        frame.dispose();
        new GameUI();
    }
}