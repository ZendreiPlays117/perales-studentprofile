package TrolleyProblemGame;

public class VaccineDilemma extends Dilemma {
    
    public VaccineDilemma() {
        this.title = "== THE VACCINE DILEMMA ==";
        this.description = "You have a limited vaccine that can save 1000 lives. But the vaccine " +
                           "has a side effect: it will cause permanent paralysis in 10 people. " +
                           "Do you distribute the vaccine?\n" +
                           "What do you do?";
        this.options = new String[]{
            "Distribute it - save 1000 at the cost of 10 paralyzed",
            "Don't distribute it - let 1000 die, 0 paralyzed",
            "Distribute only to volunteers who accept the risk",
            "Try to develop a safer vaccine (takes too long)"
        };
        this.moralityImpacts = new int[]{4, -4, 2, -2};
        this.chaosImpacts = new int[]{-1, 2, 1, 5};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Distribute
            "== YOU DISTRIBUTED THE VACCINE. ==\n\n" +
            "The vaccine ships out. 1000 people receive the injection. 990 walk away healthy. \n" +
            "10 wake up unable to move their legs. Their screams echo through hospital corridors.\n\n" +
            "'You saved my life,' one paralyzed patient tells you, 'but you ruined it too. I can't \n" +
            "hold my daughter anymore. I can't walk her down the aisle. Was it worth it for me?'\n\n" +
            "The math says yes. 10 paralyzed vs 1000 dead. But math doesn't have to look into \n" +
            "the eyes of the ones you sacrificed. You saved a thousand families from grief. \n" +
            "You destroyed ten families with guilt.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Greatest good for greatest number)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Predictable outcome)",
            
            // Choice 2: Don't distribute
            "== YOU DID NOT DISTRIBUTE THE VACCINE. ==\n\n" +
            "The vaccine sits in cold storage while the disease spreads. 1000 people die, one by one. \n" +
            "Families weep at funerals. Hospitals overflow. The news plays a constant loop of \n" +
            "the dead.\n\n" +
            "'Why didn't you do something?' a widow screams at you. 'My husband would have accepted \n" +
            "paralysis! He would have wanted to live for our children!'\n\n" +
            "You explain that you couldn't risk paralyzing anyone. She doesn't understand. She \n" +
            "never will. Your hands are clean of paralysis. But they're stained with the blood \n" +
            "of 1000 preventable deaths.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Do no harm - even by omission)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Stubborn principle)",
            
            // Choice 3: Volunteers only
            "== YOU DISTRIBUTED ONLY TO VOLUNTEERS. ==\n\n" +
            "You announce the risk publicly. 'Who will accept paralysis to save their own life?' \n" +
            "800 people volunteer. You have enough for all of them and 200 extra doses.\n\n" +
            "But 200 people who would have volunteered didn't hear the announcement in time. \n" +
            "They die. Their families blame you. 'Why didn't you just make the choice for us?' \n" +
            "they ask. 'We would have said yes.'\n\n" +
            "200 die because you respected autonomy. The 800 who volunteered are grateful, but \n" +
            "guilty. They survived while others didn't. Choice is a burden as heavy as fate.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Respecting autonomy)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Moderate approach)",
            
            // Choice 4: Develop safer vaccine
            "== YOU TRIED TO DEVELOP A SAFER VACCINE. ==\n\n" +
            "'We can do better,' you announce. 'We'll make a vaccine that doesn't paralyze anyone.' \n" +
            "The research begins. Months pass. Years pass.\n\n" +
            "While you wait for perfection, the disease spreads. 10,000 die. 20,000. 50,000. \n" +
            "The improved vaccine finally arrives - on the same day the disease burns itself out.\n\n" +
            "You have a perfect vaccine for a disease that no longer exists. 50,000 people are \n" +
            "dead because you wouldn't accept imperfection. Perfectionism, in a crisis, is just \n" +
            "procrastination with moral weight.\n\n" +
            "The safe vaccine sits unused. Your conscience isn't clean at all.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Perfect is the enemy of good)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Unexpected delay)"
        };
        return messages[choice];
    }
}