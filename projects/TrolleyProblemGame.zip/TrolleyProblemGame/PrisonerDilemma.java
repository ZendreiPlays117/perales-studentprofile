package TrolleyProblemGame;

public class PrisonerDilemma extends Dilemma {
    
    public PrisonerDilemma() {
        this.title = "== THE PRISONER'S DILEMMA ==";
        this.description = "You and your partner are arrested for a crime. The police offer a deal: " +
                           "if you confess and your partner stays silent, you go free and they get 10 years. " +
                           "If you both confess, you each get 5 years. If both stay silent, you each get 1 year.\n" +
                           "What do you do?";
        this.options = new String[]{
            "Confess - betray your partner for freedom",
            "Stay silent - trust your partner to do the same",
            "Confess and warn your partner first",
            "Refuse to speak at all (contempt of court)"
        };
        this.moralityImpacts = new int[]{-3, 2, 1, -2};
        this.chaosImpacts = new int[]{1, -2, 4, 7};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Confess
            "== YOU CONFESSED. ==\n\n" +
            "You sign the confession without hesitation. 'I did it,' you tell the detective. \n" +
            "'My partner was just following orders.' The deal is made. You walk free.\n\n" +
            "Your partner didn't confess. They trusted you. Now they're serving 10 years in a \n" +
            "maximum security prison. Their wife visits you, crying. 'Why?' she asks.\n\n" +
            "You have no good answer. You're free, but freedom tastes like betrayal. Every time \n" +
            "you see a police car, you flinch. Every time the phone rings, you expect it to be \n" +
            "your partner, calling from prison, asking how you could do this to them.\n\n" +
            "Sometimes the rational choice is the worst choice for your soul.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Self-interest over loyalty)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Predictable betrayal)",
            
            // Choice 2: Stay silent
            "== YOU STAYED SILENT. ==\n\n" +
            "You refuse to confess. 'I have nothing to say,' you repeat, over and over. \n" +
            "The detective is frustrated. Your partner, sitting in another room, also stays silent.\n\n" +
            "The prosecution has no case. After a year, you're both released. You walk out \n" +
            "together into the sunlight. Your partner hugs you. 'Thank you for trusting me,' they say.\n\n" +
            "You could have betrayed them. You could have walked free immediately. Instead, \n" +
            "you spent a year in jail, uncertain whether they would do the same.\n\n" +
            "But you kept your integrity. You proved that trust can survive even the worst \n" +
            "situations. Your friendship will never be the same - it's stronger now.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Loyalty and trust)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Risk-taking trust)",
            
            // Choice 3: Confess and warn
            "== YOU CONFESSED BUT WARNED YOUR PARTNER FIRST. ==\n\n" +
            "Before signing anything, you whisper to your partner: 'I'm going to confess. \n" +
            "You should too. It's the only way we both get less time.'\n\n" +
            "Your partner nods, reluctantly. You both confess. The judge gives you each 5 years.\n\n" +
            "It's not ideal. But you're serving the same sentence, together. And your partner \n" +
            "doesn't feel betrayed - you gave them a choice. They made the same decision you did.\n\n" +
            "In prison, you share a cell. You talk about what you'll do when you get out. \n" +
            "You play cards. You survive together. Was it the right choice? Not really. \n" +
            "But it was the honest one.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Honest betrayal? Mixed)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Unexpected transparency)",
            
            // Choice 4: Refuse to speak
            "== YOU REFUSED TO SPEAK AT ALL. ==\n\n" +
            "You sit in silence. No confession. No denial. No words at all. The prosecution \n" +
            "can't do anything without evidence. The judge holds you in contempt.\n\n" +
            "You're sentenced to 6 months for contempt, then released. Your partner, following \n" +
            "your lead, also stays silent. They're released too.\n\n" +
            "Neither of you confessed. Neither of you betrayed anyone. But you wasted the court's \n" +
            "time, the public's money, and your own freedom.\n\n" +
            "Was it principle or stubbornness? Even you're not sure. You made a point. \n" +
            "But you're not certain what point you made.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Purely principled)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Chaotic resistance)"
        };
        return messages[choice];
    }
}