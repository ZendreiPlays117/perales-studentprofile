package TrolleyProblemGame;

import java.util.ArrayList;
import java.util.List;

public class Player {
    private String name;
    private int moralityScore = 0;
    private int chaosScore = 0;
    private List<Dilemma> history = new ArrayList<>();
    
    public Player(String name) {
        this.name = name;
    }
    
    public String getName() {
        return name;
    }
    
    public void addMoralityScore(int points) {
        moralityScore += points;
    }
    
    public void addChaosScore(int points) {
        chaosScore += points;
    }
    
    public int getMoralityScore() {
        return moralityScore;
    }
    
    public int getChaosScore() {
        return chaosScore;
    }
    
    public void addToHistory(Dilemma dilemma) {
        history.add(dilemma);
    }
    
    public List<Dilemma> getHistory() {
        return new ArrayList<>(history);
    }
    
    public String getMoralAlignment() {
        if (moralityScore >= 15) {
            return "Firmly Moral";
        } else if (moralityScore >= 8) {
            return "Moral";
        } else if (moralityScore >= 0) {
            return "Neutral";
        } else if (moralityScore >= -8) {
            return "Amoral";
        } else {
            return "Immoral";
        }
    }
    
    public String getChaosAlignment() {
        if (chaosScore >= 20) {
            return "Completely Chaotic";
        } else if (chaosScore >= 12) {
            return "Very Chaotic";
        } else if (chaosScore >= 5) {
            return "Somewhat Chaotic";
        } else if (chaosScore >= -5) {
            return "Balanced";
        } else {
            return "Orderly";
        }
    }
}
