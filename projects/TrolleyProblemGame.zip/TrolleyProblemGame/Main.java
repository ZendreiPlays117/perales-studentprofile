package TrolleyProblemGame;

import javax.swing.SwingUtilities;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        try {
            // Use SwingUtilities.invokeLater to ensure proper thread handling
            SwingUtilities.invokeLater(() -> {
                try {
                    new GameUI();
                } catch (Exception e) {
                    e.printStackTrace();
                    JOptionPane.showMessageDialog(null, 
                        "Error starting GameUI: " + e.getMessage(),
                        "Startup Error", 
                        JOptionPane.ERROR_MESSAGE);
                }
            });
        } catch (Exception e) {
            System.err.println("Failed to start application: " + e.getMessage());
            e.printStackTrace();
        }
    }
}