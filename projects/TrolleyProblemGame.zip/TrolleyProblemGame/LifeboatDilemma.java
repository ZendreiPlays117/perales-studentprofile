package TrolleyProblemGame;

public class LifeboatDilemma extends Dilemma {
    
    public LifeboatDilemma() {
        this.title = "== THE LIFEBOAT DILEMMA ==";
        this.description = "You're on a sinking ship with 10 survivors but only 5 spots on the lifeboat. " +
                           "If you don't act, all 10 will drown. You can choose who gets on the boat, " +
                           "but you must leave 5 behind.\n" +
                           "What do you do?";
        this.options = new String[]{
            "Choose randomly - fair chance for everyone",
            "Save the youngest 5 - they have more life ahead",
            "Save the most skilled 5 - doctors, engineers, etc.",
            "Let everyone fight for themselves (natural selection)"
        };
        this.moralityImpacts = new int[]{0, 3, 2, -4};
        this.chaosImpacts = new int[]{5, -1, 0, 8};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Choose randomly
            "== YOU CHOSE RANDOMLY. ==\n\n" +
            "You close your eyes and point. 'You, you, you, you, and you. Get in.' The chosen five \n" +
            "scramble into the lifeboat, tears streaming down their faces. The other five watch \n" +
            "in horror as you push off. 'Why them?' someone screams. 'Why not me?'\n\n" +
            "You have no answer. Luck is not a reason. As the ship sinks behind you, the five \n" +
            "survivors stare at you with hollow eyes. They lived, but they'll never understand why.\n" +
            "You saved five lives. But you condemned five others to death by pure chance.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Morally neutral randomness)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Chaotic fairness)",
            
            // Choice 2: Save youngest
            "== YOU SAVED THE YOUNGEST 5. ==\n\n" +
            "You push through the crowd, grabbing children and teenagers. 'They have their whole \n" +
            "lives ahead of them!' you shout. The elderly and middle-aged watch in silence as \n" +
            "you load the young onto the boat.\n\n" +
            "An old man touches your arm. 'I was young once too,' he whispers. 'My life still \n" +
            "matters.' You can't meet his eyes. As the boat lowers into the water, you hear \n" +
            "the young ones crying for their parents left behind.\n\n" +
            "You saved potential. But you sacrificed experience, wisdom, and love. Was it worth it?\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Future potential over present)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Calculated decision)",
            
            // Choice 3: Save most skilled
            "== YOU SAVED THE MOST SKILLED 5. ==\n\n" +
            "'Doctors, engineers, scientists - get on the boat!' you command. The five most \n" +
            "educated survivors climb aboard, their faces pale with guilt. A mother clutches \n" +
            "her child, both left behind. 'My son could cure cancer someday,' she pleads.\n\n" +
            "'Could,' you say. 'These people already have.' The boat pulls away. The two doctors \n" +
            "immediately start helping the injured. The engineer rigs a sail. You saved utility.\n\n" +
            "But as you watch the ship sink, you wonder: who decides what skill matters? The \n" +
            "artist who paints beauty into the world? The janitor who keeps hospitals clean? \n" +
            "Value is not so easily measured.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Utilitarian calculation)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Cold logic)",
            
            // Choice 4: Natural selection
            "== YOU LET EVERYONE FIGHT FOR THEMSELVES. ==\n\n" +
            "You step back. 'Survival of the fittest,' you announce. Chaos erupts. Strong men \n" +
            "shove aside the weak. Women claw at each other. A teenager is trampled. A grandmother \n" +
            "is thrown overboard. The lifeboat fills with the most aggressive, not the most worthy.\n\n" +
            "When it's over, 8 people are dead - more than necessary. The 5 who made it onto the \n" +
            "boat are bruised, bleeding, and broken. They won't look at each other. They won't \n" +
            "look at you.\n\n" +
            "You didn't choose who died. But your choice to abstain from choosing cost extra lives.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Refusing responsibility)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Maximum chaos)"
        };
        return messages[choice];
    }
}