package TrolleyProblemGame;

public class EnvironmentalDilemma extends Dilemma {
    
    public EnvironmentalDilemma() {
        this.title = "THE ENVIRONMENTAL DILEMMA";
        this.description = "A factory in a poor town employs 500 people. The factory pollutes a river, " +
                           "causing cancer in 50 residents per year. Do you shut it down?\n" +
                           "What do you do?";
        this.options = new String[]{
            "Shut it down - save the 50, 500 lose jobs",
            "Keep it open - 500 keep jobs, 50 die yearly",
            "Force expensive clean-up (town goes bankrupt)",
            "Relocate the factory elsewhere"
        };
        this.moralityImpacts = new int[]{2, -3, 1, 0};
        this.chaosImpacts = new int[]{-1, 0, 4, 6};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Shut it down
            "YOU SHUT DOWN THE FACTORY.\n\n" +
            "You post the closure notice. Within a week, 500 people are unemployed. The town \n" +
            "dies. Shops close. Families move away. Children go hungry.\n\n" +
            "But the river cleans up. Cancer rates drop. 50 people per year stop dying. \n" +
            "Over a decade, you save 500 lives - the same number as lost their jobs.\n\n" +
            "The math is even. The suffering is not. The unemployed blame you. The cancer \n" +
            "survivors thank you. You stand in the middle, hated and loved, wondering if any \n" +
            "choice could have been good.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Lives vs livelihoods)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Predictable shutdown)",
            
            // Choice 2: Keep it open
            "YOU KEPT THE FACTORY OPEN.\n\n" +
            "'Jobs matter,' you announce. 'My priority is the workers.' The factory continues \n" +
            "to operate. 500 families stay fed. The town survives.\n\n" +
            "But every year, 50 people die of cancer. You attend funeral after funeral. \n" +
            "Children lose parents. Parents lose children. The river glows at night, poisoned.\n\n" +
            "A dying patient grabs your hand. 'You chose jobs over my life,' they whisper. \n" +
            "'I hope it was worth it.' You don't have an answer.\n\n" +
            "You saved 500 families from poverty. You sacrificed 50 families per year to cancer.\n" +
            "Over 10 years, that's 500 lives. Exactly the same number. No winners.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Prioritizing economy)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Status quo)",
            
            // Choice 3: Expensive clean-up
            "YOU FORCED AN EXPENSIVE CLEAN-UP.\n\n" +
            "The factory installs filters and treatment systems. The river starts to heal. \n" +
            "Cancer rates drop. But the clean-up cost bankrupts the town.\n\n" +
            "The factory closes anyway - not because of pollution, but because of debt. \n" +
            "The 500 workers lose their jobs. The town dies. AND 50 people per year still \n" +
            "die from legacy pollution that won't clear for decades.\n\n" +
            "You tried to have it all. You ended up with the worst of both worlds: unemployed \n" +
            "workers AND dying residents. Everyone hates you. The town becomes a ghost town.\n\n" +
            "Sometimes compromise isn't the middle ground. Sometimes it's the worst ground.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Failed compromise)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Chaotic middle ground)",
            
            // Choice 4: Relocate factory
            "YOU RELOCATED THE FACTORY.\n\n" +
            "You find another town willing to accept the factory. The building moves. \n" +
            "500 workers move with it. The original town is saved from pollution.\n\n" +
            "But the new town now has the same problem: jobs vs cancer. The factory pollutes \n" +
            "a different river. 50 people in the new town will die every year. You saved your \n" +
            "town by sacrificing another.\n\n" +
            "Are the lives in the new town worth less than the lives in the old town? \n" +
            "You've learned that geography is not morality. You solved nothing - you just \n" +
            "moved the problem somewhere you don't have to see it.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Out of sight, out of mind?)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Unexpected relocation)"
        };
        return messages[choice];
    }
}