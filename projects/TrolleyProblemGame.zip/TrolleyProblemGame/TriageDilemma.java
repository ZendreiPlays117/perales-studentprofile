package TrolleyProblemGame;

public class TriageDilemma extends Dilemma {
    
    public TriageDilemma() {
        this.title = "== THE TRIAGE DILEMMA ==";
        this.description = "You're the only doctor in a disaster zone. 10 patients need surgery. " +
                           "You can save 9 if you ignore 1 who will take too long. Do you save the 9?\n" +
                           "What do you do?";
        this.options = new String[]{
            "Save the 9 - ignore the complex case",
            "Save the 1 - let the 9 die",
            "Try to save all 10 (risk losing everyone)",
            "Save the youngest 5, oldest 5 die"
        };
        this.moralityImpacts = new int[]{5, -5, -3, 2};
        this.chaosImpacts = new int[]{-2, 3, 8, 1};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Save 9
            "== YOU SAVED THE 9. ==\n\n" +
            "You make the call. 'We don't have time for the complex case.' The team focuses on \n" +
            "the 9 simple surgeries. One by one, they survive. By the end of the day, 9 people \n" +
            "are alive.\n\n" +
            "The 10th patient dies alone, in a corner, while you're saving others. The nurse \n" +
            "assigned to hold their hand. 'Is anyone coming for me?' they ask, over and over. \n" +
            "No one comes.\n\n" +
            "You saved 9 families from grief. You destroyed 1. The math works. But you have to \n" +
            "live with the knowledge that you decided who lived and who died. The 9 survivors \n" +
            "don't know about the 10th. You hope they never find out.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Triage - save the many)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Cold medical logic)",
            
            // Choice 2: Save 1
            "== YOU SAVED THE 1 COMPLEX CASE. ==\n\n" +
            "'Every life is worth saving,' you insist. You spend 10 hours on the complex surgery. \n" +
            "It's delicate, precise, beautiful work. The patient survives.\n\n" +
            "You emerge from the operating room to find 9 bodies. The simple cases died while \n" +
            "you were working on the complex one. Their families are weeping. Their blood is \n" +
            "on your hands.\n\n" +
            "The patient you saved doesn't thank you. 'You should have let me die,' they say. \n" +
            "'I'm not worth 9 lives. No one is.' They're right. You know they're right.\n\n" +
            "You saved one person at the cost of 9. The math is terrible. Your conscience is worse.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Equal value, unequal time)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Unpredictable priority)",
            
            // Choice 3: Try to save all
            "== YOU TRIED TO SAVE ALL 10. ==\n\n" +
            "'No one gets left behind,' you announce. You try to do all 10 surgeries simultaneously, \n" +
            "moving from patient to patient, never focusing on any for long enough.\n\n" +
            "It's chaos. You make mistakes in every surgery. Patients bleed out while you're \n" +
            "working on others. By midnight, all 10 are dead.\n\n" +
            "You killed everyone by trying to save everyone. Your ambition exceeded your ability. \n" +
            "Your compassion overwhelmed your competence.\n\n" +
            "The 9 patients who would have survived are dead because you refused to choose. \n" +
            "The 1 complex patient is dead too. You have no survivors and no defense.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Overambitious compassion)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Chaotic heroism)",
            
            // Choice 4: Save youngest
            "== YOU SAVED THE YOUNGEST 5. ==\n\n" +
            "'They have more life ahead,' you rationalize. You operate on the 5 youngest patients. \n" +
            "They survive. The 5 oldest die.\n\n" +
            "An old man grabs your arm before he dies. 'I raised 4 children,' he whispers. \n" +
            "'I worked 50 years. I paid taxes. I loved my wife. My life mattered too.'\n\n" +
            "He's right. His life mattered. But you decided it mattered less.\n\n" +
            "The children you saved will grow up. They'll have families, careers, lives. \n" +
            "But every birthday will be haunted by the knowledge that others died so they could live.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Age-based triage)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Expected age discrimination)"
        };
        return messages[choice];
    }
}