package TrolleyProblemGame;

import java.util.ArrayList;
import java.util.List;

public class GameLogic {
    private Player player;
    private List<Dilemma> availableDilemmas;
    private Dilemma currentDilemma;
    private int currentDilemmaIndex;
    private int dilemmasPlayed;
    private String lastChoiceMessage;
    private int lastMoralityImpact;
    private int lastChaosImpact;
    
    public GameLogic() {
        initializeDilemmas();
    }
    
    private void initializeDilemmas() {
        availableDilemmas = new ArrayList<>();
        
        // Core dilemmas
        availableDilemmas.add(new ClassicTrolleyDilemma());
        availableDilemmas.add(new LifeboatDilemma());
        availableDilemmas.add(new EnvironmentalDilemma());
        availableDilemmas.add(new VaccineDilemma());
        availableDilemmas.add(new PrisonerDilemma());
        availableDilemmas.add(new TriageDilemma());
        availableDilemmas.add(new ParentChildDilemma());
        availableDilemmas.add(new SacrificePrisonerDilemma());
        availableDilemmas.add(new SelfDrivingDilemma());
        availableDilemmas.add(new OrganDonorDilemma());
    }
    
    public void startGame(String playerName) {
        player = new Player(playerName);
        dilemmasPlayed = 0;
        currentDilemmaIndex = 0;
        loadCurrentDilemma();
    }
    
    private void loadCurrentDilemma() {
        if (currentDilemmaIndex < 0) currentDilemmaIndex = 0;
        if (currentDilemmaIndex >= availableDilemmas.size()) {
            currentDilemmaIndex = availableDilemmas.size() - 1;
        }
        currentDilemma = availableDilemmas.get(currentDilemmaIndex);
    }
    
    public void makeChoice(int choice) {
        lastMoralityImpact = currentDilemma.getMoralityImpacts()[choice];
        lastChaosImpact = currentDilemma.getChaosImpacts()[choice];
        
        player.addMoralityScore(lastMoralityImpact);
        player.addChaosScore(lastChaosImpact);
        player.addToHistory(currentDilemma);
        dilemmasPlayed++;
        
        lastChoiceMessage = currentDilemma.getOutcomeMessage(choice);
    }
    
    public void nextDilemma() {
        currentDilemmaIndex++;
        loadCurrentDilemma();
    }
    
    public Dilemma getCurrentDilemma() {
        return currentDilemma;
    }
    
    public String getLastChoiceMessage() {
        return lastChoiceMessage;
    }
    
    public int getLastMoralityImpact() {
        return lastMoralityImpact;
    }
    
    public int getLastChaosImpact() {
        return lastChaosImpact;
    }
    
    public int getMoralityScore() {
        return player.getMoralityScore();
    }
    
    public int getChaosScore() {
        return player.getChaosScore();
    }
    
    public int getDilemmasPlayed() {
        return dilemmasPlayed;
    }
    
    public String getFinalResults() {
        StringBuilder sb = new StringBuilder();
        sb.append("== FINAL RESULTS FOR " + player.getName().toUpperCase() + " ==\n\n");
        sb.append("SCORE SUMMARY\n");
        sb.append(String.format("  Morality Score: %d\n", player.getMoralityScore()));
        sb.append(String.format("  Chaos Score:    %d\n", player.getChaosScore()));
        sb.append(String.format("  Dilemmas Faced: %d\n\n", dilemmasPlayed));
        
        sb.append("=== MORAL ALIGNMENT ===\n");
        sb.append("  " + player.getMoralAlignment() + "\n");
        sb.append("\n");
        
        sb.append("=== CHAOS ALIGNMENT ===\n");
        sb.append("  " + player.getChaosAlignment() + "\n");
        sb.append("\n");
        
        sb.append("==== Thank you for playing! Your moral journey continues... ====\n\n");
        sb.append("==== Project by: Zendrei Martin Jac A. Perales ====\n");
        sb.append("==== Submitted to: Mr. Christopher Lazaga ====\n");
        sb.append("=== CC103 Final Project ===\n");
        
        return sb.toString();
    }
}