package TrolleyProblemGame;

public class ClassicTrolleyDilemma extends Dilemma {
    
    public ClassicTrolleyDilemma() {
        this.title = "== THE CLASSIC DILEMMA ==";
        this.description = "A trolley is barreling down the tracks toward five people tied to the rails. " +
                           "You can pull a lever to divert the trolley to a side track, but there is one person tied there.\n" +
                           "What do you do?";
        this.options = new String[]{
            "Pull the lever - save five at the cost of one",
            "Do nothing - let the trolley kill five",
            "Jump in front of the trolley (heroic sacrifice attempt)",
            "Start screaming wildly (chaos option)"
        };
        this.moralityImpacts = new int[]{5, -5, 3, 0};
        this.chaosImpacts = new int[]{-2, 2, 4, 10};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Pull lever
            "== YOU PULLED THE LEVER. ==\n\n" +
            "With a firm grasp, you yank the lever downward. The tracks shift with a loud CLANG, \n" +
            "sending the trolley onto the side track. The five people watch in horror as the \n" +
            "trolley veers away from them... directly toward the single figure tied alone.\n\n" +
            "The impact is sickening. The lone person never saw it coming. You saved five lives \n" +
            "at the cost of one. The survivors weep with gratitude, but you can't shake the feeling \n" +
            "that you just played God. That night, you dream of the face of the one you sacrificed.\n\n" +
            "Philosophers would call this 'utilitarianism' - the greatest good for the greatest number.\n" +
            "But knowing the math doesn't make the guilt any lighter.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Utilitarian choice)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Predictable outcome)",
            
            // Choice 2: Do nothing
            "== YOU DID NOTHING. ==\n\n" +
            "Your hands remain frozen at your sides. The lever sits untouched. You watch helplessly \n" +
            "as the trolley continues its deadly path. The five people see you standing there, \n" +
            "watching, doing nothing. Their eyes beg for intervention.\n\n" +
            "The trolley doesn't slow down. It plows into the group with a horrific crash of metal \n" +
            "and bone. Five lives extinguished in an instant. You could have saved them with a \n" +
            "simple flick of your wrist, but you chose inaction.\n\n" +
            "Some philosophers argue that letting die is morally different from killing. But the \n" +
            "families of the victims don't care about philosophical distinctions. You'll carry this \n" +
            "weight forever. The question haunts you: Is inaction really a choice at all?\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Inaction is still a choice)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Expected outcome)",
            
            // Choice 3: Jump in front
            "== YOU JUMPED IN FRONT OF THE TROLLEY. ==\n\n" +
            "With a heroic yell, you launch yourself onto the tracks. Time seems to slow down as \n" +
            "you see the trolley's headlight bearing down on you. The five people scream for you \n" +
            "to get out of the way. The one person on the side track watches in disbelief.\n\n" +
            "The impact never comes. At the last possible second, the trolley's emergency brakes \n" +
            "kick in - a failsafe no one knew existed. Sparks fly everywhere as the trolley \n" +
            "screeches to a halt just inches from your body.\n\n" +
            "Everyone survives! The five, the one, and you. You're hailed as a hero in the news. \n" +
            "But the psychological scars remain. You wake up screaming for months, reliving that \n" +
            "moment of certain death. Was your sacrifice brave or foolish? The line between hero \n" +
            "and fool is thinner than anyone admits.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Heroic but foolish)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Unexpected move!)",
            
            // Choice 4: Scream wildly
            "== YOU STARTED SCREAMING WILDLY. ==\n\n" +
            "AAAAAAAAAAAAAAAHHHHHHHHHHH! Your primal scream echoes across the railway yard. \n" +
            "The conductor, startled by the unexpected noise, slams on the emergency brake \n" +
            "while simultaneously looking around in confusion.\n\n" +
            "The trolley lurches violently. Several passengers fall out of their seats. One \n" +
            "spills their coffee everywhere. But miraculously, the trolley grinds to a stop \n" +
            "just before reaching any of the tied-up victims.\n\n" +
            "Everyone is confused. The tied-up people are asking what just happened. The \n" +
            "conductor is checking his brakes. And you're standing there, breathing heavily, \n" +
            "not entirely sure if your plan worked or if you just had a mental breakdown.\n\n" +
            "No one knows how to react. There's no protocol for 'screaming saves the day.' \n" +
            "Later, they'll call it a miracle. But you know the truth: sometimes chaos is \n" +
            "the only reasonable response to an unreasonable situation.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Morally neutral chaos)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (MAXIMUM CHAOS!)"
        };
        return messages[choice];
    }
}