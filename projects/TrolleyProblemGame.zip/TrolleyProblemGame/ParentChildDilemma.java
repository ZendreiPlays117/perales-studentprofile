package TrolleyProblemGame;

public class ParentChildDilemma extends Dilemma {
    
    public ParentChildDilemma() {
        this.title = "== THE PARENT-CHILD DILEMMA ==";
        this.description = "Your child needs a kidney transplant or they'll die. You're a match. " +
                           "But donating will shorten your life by 10 years. Do you donate?\n" +
                           "What do you do?";
        this.options = new String[]{
            "Donate - save your child, shorten your life",
            "Don't donate - live longer, child dies",
            "Find another donor (risky, might be too late)",
            "Ask your child what they want"
        };
        this.moralityImpacts = new int[]{3, -3, 1, 2};
        this.chaosImpacts = new int[]{-1, 2, 4, -2};
    }
    
    @Override
    public String getOutcomeMessage(int choice) {
        int morality = this.moralityImpacts[choice];
        int chaos = this.chaosImpacts[choice];
        
        String[] messages = {
            // Choice 1: Donate
            "== YOU DONATED YOUR KIDNEY. ==\n\n" +
            "The surgery goes perfectly. Your child wakes up with a new kidney. Their color returns. \n" +
            "They smile at you. 'Thank you, Mom/Dad,' they say.\n\n" +
            "Your own recovery is harder. You're weaker now. Your doctor says you have 10 fewer years.\n\n" +
            "You watch your child grow up. You see them graduate. You attend their wedding. \n" +
            "You hold your grandchild. And then you die, earlier than you should have.\n\n" +
            "Your child speaks at your funeral. 'They gave me their kidney,' they say. 'They gave \n" +
            "me their life. I hope I was worth it.'\n\n" +
            "You were worth it. Every moment was worth it. But you'll never hear them say that.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Ultimate parental sacrifice)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Predictable love)",
            
            // Choice 2: Don't donate
            "== YOU DID NOT DONATE. ==\n\n" +
            "'I can't,' you tell your child. 'I'm sorry. I want to live.'\n\n" +
            "Your child nods. They understand. They don't blame you. But their eyes are hollow.\n\n" +
            "They die three months later. You hold their hand as they go.\n\n" +
            "You live another 30 years. You travel. You retire. You have hobbies. You're happy, \n" +
            "sometimes. But every holiday is empty. Every birthday is haunted.\n\n" +
            "At the end of your life, you're alone. No one visits. No one cares. You sacrificed \n" +
            "your child for 30 more years of loneliness.\n\n" +
            "Was it worth it? You have 30 years to ask yourself that question. You never find an answer.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Self-preservation)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Expected self-interest)",
            
            // Choice 3: Find another donor
            "== YOU TRIED TO FIND ANOTHER DONOR. ==\n\n" +
            "You search everywhere. Relatives. Friends. Strangers. Social media. News appeals.\n\n" +
            "No one matches. No one volunteers. Time runs out.\n\n" +
            "Your child dies on the operating table, waiting for a donor who never came.\n\n" +
            "You could have saved them. You had the kidney. You chose to look for alternatives.\n\n" +
            "There were no alternatives. There was only you. And you said no.\n\n" +
            "Your child died because you were looking for someone else to do what you wouldn't.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Delegating responsibility)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Risky search)",
            
            // Choice 4: Ask child
            "== YOU ASKED YOUR CHILD WHAT THEY WANT. ==\n\n" +
            "'Should I donate?' you ask. 'I'll live 10 fewer years. But you'll live.'\n\n" +
            "Your child thinks for a long time. 'No,' they finally say. 'I don't want you to die \n" +
            "for me. I'll take my chances.'\n\n" +
            "You try to convince them. They won't budge. 'I love you too much to lose you early,' they say.\n\n" +
            "They die three months later. You live another 30 years, haunted by their words. \n" +
            "They loved you too much to let you sacrifice for them. And you loved them too much \n" +
            "to sacrifice them for yourself.\n\n" +
            "Love, it turns out, can kill as surely as hate.\n\n" +
            "🎭 MORALITY: " + (morality > 0 ? "+" : "") + morality + " (Respecting child's autonomy)\n" +
            "🌪️ CHAOS: " + (chaos > 0 ? "+" : "") + chaos + " (Unexpected role reversal)"
        };
        return messages[choice];
    }
}